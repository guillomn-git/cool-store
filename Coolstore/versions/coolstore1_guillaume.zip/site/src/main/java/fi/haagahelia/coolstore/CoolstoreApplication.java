package fi.haagahelia.coolstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoolstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoolstoreApplication.class, args);
	}

}
