package fi.haagahelia.coolstore.domain;

public class Book {

	private String title;
	private String author;
	private String isbn;
	// for price, better to use int? TODO: investigate
	private float price;

}
