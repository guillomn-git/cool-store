package fi.haagahelia.coolstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoolstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
